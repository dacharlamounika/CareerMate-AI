import type { ResumeContent, ProjectEntry } from '@/types';
import { categorizeSkills, generateProjectBullets } from '@/features/resume/utils/analysis';

interface Props {
  content: ResumeContent;
}

export function ResumeDocument({ content }: Props) {
  const {
    profile,
    contact,
    introduction,
    education,
    experience,
    projects,
    achievements,
    certifications,
    interests,
    languages,
    references,
    skipReferences,
  } = content;

  const targetRole = content.targetRole === 'Other' ? content.customRole : content.targetRole;
  const locationText = [profile.district, profile.state].filter(Boolean).join(', ');
  const contactParts = [
    contact.email,
    contact.mobile,
    locationText,
  ].filter(Boolean);

  // Categorize skills from experience entries
  const skillCategories = categorizeSkills(experience);

  // Determine which sections have content
  const hasIntro = !!introduction.trim();
  const hasEducation = education.length > 0;
  const hasSkills = skillCategories.length > 0;
  const hasProjects = projects.length > 0;
  const hasAchievements = achievements.length > 0 && achievements.some((a) => a.title.trim());
  const hasCertifications = certifications.length > 0 && certifications.some((c) => c.name.trim());
  const hasExperience = experience.some((e) => e.context === 'Internship' || e.context === 'Professional');
  const hasInterests = interests.length > 0 && interests.some((i) => i.name.trim());
  const hasLanguages = languages.length > 0 && languages.some((l) => l.language.trim());
  const hasReferences = !skipReferences && references.length > 0 && references.some((r) => r.name.trim());

  const SectionHeading = ({ children }: { children: string }) => (
    <h2
      className="mb-2 border-b border-slate-400 pb-1 text-sm font-bold uppercase tracking-wider text-slate-800"
      style={{ fontSize: '11pt' }}
    >
      {children}
    </h2>
  );

  const ProjectItem = ({ project }: { project: ProjectEntry }) => {
    const bullets = generateProjectBullets(project);
    return (
      <div className="mb-3">
        <div className="flex items-baseline justify-between">
          <span className="font-bold text-slate-900" style={{ fontSize: '11pt' }}>
            {project.title.toUpperCase()}
          </span>
          {project.type && (
            <span className="text-slate-500 italic" style={{ fontSize: '10pt' }}>
              {project.type} Project
            </span>
          )}
        </div>
        {project.technologies && (
          <p className="mt-0.5 font-medium text-slate-700" style={{ fontSize: '10.5pt' }}>
            {project.technologies}
          </p>
        )}
        {bullets.length > 0 && (
          <ul className="mt-1 list-disc space-y-0.5 pl-5 text-slate-700">
            {bullets.map((bullet, i) => (
              <li key={i}>{bullet}</li>
            ))}
          </ul>
        )}
        {(project.githubUrl || project.demoUrl) && (
          <div className="mt-1 flex gap-3" style={{ fontSize: '9.5pt' }}>
            {project.githubUrl && (
              <a href={project.githubUrl} className="text-teal-700">
                GitHub
              </a>
            )}
            {project.demoUrl && (
              <a href={project.demoUrl} className="text-teal-700">
                Demo
              </a>
            )}
          </div>
        )}
      </div>
    );
  };

  return (
    <div
      data-print-root
      className="bg-white text-slate-900"
      style={{
        fontFamily: 'Inter, Arial, sans-serif',
        fontSize: '11pt',
        lineHeight: 1.55,
        padding: '0',
        minHeight: '297mm',
      }}
    >
      {/* Inner padding wrapper for consistent margins */}
      <div style={{ padding: '20px 28px' }}>
        {/* Header */}
        <div className="text-center">
          <h1
            className="font-bold tracking-tight text-slate-900"
            style={{ fontSize: '20pt', letterSpacing: '0.5px' }}
          >
            {(profile.fullName || 'Your Name').toUpperCase()}
          </h1>
          {targetRole && (
            <p
              className="mt-1 font-medium text-slate-700"
              style={{ fontSize: '12pt' }}
            >
              {targetRole}
            </p>
          )}
          {contactParts.length > 0 && (
            <p className="mt-2 text-slate-600" style={{ fontSize: '10pt' }}>
              {contactParts.join(' | ')}
            </p>
          )}
        </div>

        <div className="my-3 border-t-2 border-slate-800" />

        {/* Professional Summary */}
        {hasIntro && (
          <section className="mb-4">
            <SectionHeading>Professional Summary</SectionHeading>
            <p className="text-slate-700">{introduction}</p>
          </section>
        )}

        {/* Education */}
        {hasEducation && (
          <section className="mb-4">
            <SectionHeading>Education</SectionHeading>
            <div className="space-y-1.5">
              {education.map((e) => {
                const degree = e.degree === 'Other' && e.customDegree ? e.customDegree : e.degree;
                const spec = e.specialization === 'Other' && e.customSpecialization ? e.customSpecialization : e.specialization;
                return (
                <div key={e.id}>
                  <div className="flex items-baseline justify-between">
                    <span className="font-semibold text-slate-900">
                      {degree}
                      {spec ? `, ${spec}` : ''}
                    </span>
                    {e.yearGraduation && (
                      <span className="text-slate-600" style={{ fontSize: '10pt' }}>
                        {e.yearGraduation}
                      </span>
                    )}
                  </div>
                  <div className="text-slate-700">
                    {e.institution === 'Other' && e.customInstitution ? e.customInstitution : e.institution}
                    {e.cgpa && ` — CGPA: ${e.cgpa}`}
                  </div>
                </div>
              );
            })}
            </div>
          </section>
        )}

        {/* Technical Skills — categorized */}
        {hasSkills && (
          <section className="mb-4">
            <SectionHeading>Technical Skills</SectionHeading>
            <div className="space-y-0.5">
              {skillCategories.map((cat) => (
                <div key={cat.label} className="flex gap-2 text-slate-700">
                  <span className="font-semibold min-w-fit">{cat.label}:</span>
                  <span>{cat.skills.join(', ')}</span>
                </div>
              ))}
            </div>
          </section>
        )}

        {/* Projects — with bullet points */}
        {hasProjects && (
          <section className="mb-4">
            <SectionHeading>Projects</SectionHeading>
            <div className="space-y-3">
              {projects
                .filter((p) => p.title.trim())
                .map((project) => (
                  <ProjectItem key={project.id} project={project} />
                ))}
            </div>
          </section>
        )}

        {/* Achievements — only if entries have actual titles */}
        {hasAchievements && (
          <section className="mb-4">
            <SectionHeading>Achievements</SectionHeading>
            <ul className="list-disc space-y-0.5 pl-5 text-slate-700">
              {achievements
                .filter((a) => a.title.trim())
                .map((a) => (
                  <li key={a.id}>
                    <span className="font-medium">{a.title}</span>
                    {a.organization && ` — ${a.organization}`}
                    {a.description && ` — ${a.description}`}
                  </li>
                ))}
            </ul>
          </section>
        )}

        {/* Certifications */}
        {hasCertifications && (
          <section className="mb-4">
            <SectionHeading>Certifications</SectionHeading>
            <div className="space-y-0.5">
              {certifications
                .filter((c) => c.name.trim())
                .map((c) => (
                  <div key={c.id} className="text-slate-700">
                    <span className="font-medium">{c.name}</span>
                    {c.organization && ` — ${c.organization}`}
                    {c.completionDate && (
                      <span className="text-slate-500"> ({c.completionDate})</span>
                    )}
                    {c.credentialUrl && (
                      <a href={c.credentialUrl} className="text-teal-700 ml-1">
                        [View]
                      </a>
                    )}
                  </div>
                ))}
            </div>
          </section>
        )}

        {/* Experience / Internship — only Internship and Professional contexts */}
        {hasExperience && (
          <section className="mb-4">
            <SectionHeading>Experience / Internship</SectionHeading>
            <div className="space-y-2">
              {experience
                .filter((e) => e.context === 'Internship' || e.context === 'Professional')
                .map((e) => (
                  <div key={e.id}>
                    <div className="flex items-baseline justify-between">
                      <span className="font-semibold text-slate-900">
                        {e.role || (e.context === 'Internship' ? 'Internship' : 'Professional Experience')}
                        {e.company && ` — ${e.company}`}
                        {e.technology && ` · ${e.technology}`}
                      </span>
                      {e.duration && (
                        <span className="text-slate-600" style={{ fontSize: '10pt' }}>
                          {e.duration}
                        </span>
                      )}
                    </div>
                    {e.description && <p className="text-slate-700">{e.description}</p>}
                  </div>
                ))}
            </div>
          </section>
        )}

        {/* Interests */}
        {hasInterests && (
          <section className="mb-4">
            <SectionHeading>Interests</SectionHeading>
            <p className="text-slate-700">
              {interests.map((i) => i.name).join(', ')}
            </p>
          </section>
        )}

        {/* Languages */}
        {hasLanguages && (
          <section className="mb-4">
            <SectionHeading>Languages</SectionHeading>
            <p className="text-slate-700">
              {languages
                .filter((l) => l.language.trim())
                .map((l) => `${l.language} (${l.proficiency})`)
                .join(', ')}
            </p>
          </section>
        )}

        {/* References — only if not skipped and has real entries */}
        {hasReferences && (
          <section>
            <SectionHeading>References</SectionHeading>
            <div className="grid grid-cols-2 gap-3">
              {references
                .filter((r) => r.name.trim())
                .map((r) => (
                  <div key={r.id} className="text-slate-700" style={{ fontSize: '10pt' }}>
                    <p className="font-medium">{r.name}</p>
                    {r.designation && <p>{r.designation}</p>}
                    {r.organization && <p>{r.organization}</p>}
                    {r.email && <p>{r.email}</p>}
                    {r.phone && <p>{r.phone}</p>}
                  </div>
                ))}
            </div>
          </section>
        )}
      </div>
    </div>
  );
}
